# Laravel Quiz Bot

> This is a Telegram bot built with botman and Laravel 8.

This bot has questions on different tracks which user can select and answer questions on. 
User is awarded points based on question.
User can be added on a global leaderboard at the end of the quiz.

You can check it out at [@laraquizprobot](http://t.me/laraquizprobot).


## Contributing

I am open for new features and improvements, but please talk to me first before working on a pull request.

## License

The MIT License (MIT).

