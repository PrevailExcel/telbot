<?php
return [
'conversation_cache_time' => 40,
'user_cache_time' => 30,
];